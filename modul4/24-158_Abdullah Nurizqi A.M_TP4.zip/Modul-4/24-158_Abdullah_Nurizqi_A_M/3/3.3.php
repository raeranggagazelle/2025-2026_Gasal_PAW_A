<!-- contoh filter  -->

<?php
$email = "uqitzy@gmaul.com";
$url = "https://www.google.com";
$angka = "3.14";

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Email valid.<br>";
} else {
    echo "Email tidak valid.<br>";
}

if (filter_var($url, FILTER_VALIDATE_URL)) {
    echo "URL valid.<br>";
}

if (filter_var($angka, FILTER_VALIDATE_FLOAT)) {
    echo "Angka valid (float).<br>";
}

?>
