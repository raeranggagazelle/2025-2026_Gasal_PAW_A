<!-- contoh date validation  -->

<?php
$bulan = 2;  // Februari
$hari = 29;
$tahun = 2024;

if (checkdate($bulan, $hari, $tahun)) {
    echo "Tanggal valid ($hari/$bulan/$tahun).<br>";
} else {
    echo "Tanggal tidak valid!<br>";
}
?>
