<!-- contoh string -->
 <?php
$input = "   Halo Dunia   ";
$trimmed = trim($input);             
$lower = strtolower($trimmed);    
$upper = strtoupper($trimmed);  

echo "Asli: '$input'<br>";
echo "Setelah trim: '$trimmed'<br>";
echo "Huruf kecil: '$lower'<br>";
echo "Huruf besar: '$upper'<br>";
?>
