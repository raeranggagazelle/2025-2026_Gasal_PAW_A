<!-- contoh regex -->
<?php
$nama = "Abdullah Nurizqi";
if (preg_match("/^[a-zA-Z ]+$/", $nama)) {
    echo "Nama valid (hanya huruf dan spasi).<br>";
} else {
    echo "Nama tidak valid!<br>";
}
?>
