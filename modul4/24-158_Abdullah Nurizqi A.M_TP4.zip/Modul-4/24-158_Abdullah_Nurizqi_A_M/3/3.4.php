<!-- contoh type testing  -->

<?php
$nilai1 = 10;
$nilai2 = 10.5;
$nilai3 = "123";

if (is_int($nilai1)) echo "nilai1 adalah integer.<br>";
if (is_float($nilai2)) echo "nilai2 adalah float.<br>";
if (is_numeric($nilai3)) echo "nilai3 berupa angka (numeric string).<br>";
if (is_string($nilai3)) echo "nilai3 juga bertipe string.<br>";
?>
