<?php
$errors = [];
$nama = $nim = $email = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama']);
    if (empty($nama)) {
        $errors['nama'] = "Nama wajib diisi.";
    } elseif (!preg_match("/^[a-zA-Z' ]+$/", $nama)) {
        $errors['nama'] = "Nama hanya boleh berisi huruf dan spasi.";
    }
    $nim = trim($_POST['nim']);
    if (empty($nim)) {
        $errors['nim'] = "NIM wajib diisi.";
    } elseif (!is_numeric($nim) || strlen($nim) != 9) {
        $errors['nim'] = "NIM harus berupa 9 digit angka.";
    }
    $email = trim($_POST['email']);
    if (empty($email)) {
        $errors['email'] = "Email wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Format email tidak valid.";
    } elseif (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
        $errors['email'] = "Email harus menggunakan domain gmail.com.";
    }

    $password = trim($_POST['password']);
    if (empty($password)) {
        $errors['password'] = "Password wajib diisi.";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "Password minimal 8 karakter.";
    }

    if (empty($errors)) {
        echo "<h3> Data valid dan berhasil dikirim!</h3>";
        echo "<p><strong>Nama:</strong> " . htmlspecialchars($nama) . "</p>";
        echo "<p><strong>NIM:</strong> " . htmlspecialchars($nim) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Validasi Lanjutan</title>
</head>
<body>



<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="nama">Nama:</label>
    <input type="text" id="nama" name="nama" value="<?php echo htmlspecialchars($nama); ?>">
    <div class="error"><?php echo $errors['nama'] ?? ''; ?></div>

    <label for="nim">NIM:</label>
    <input type="text" id="nim" name="nim" value="<?php echo htmlspecialchars($nim); ?>">
    <div class="error"><?php echo $errors['nim'] ?? ''; ?></div>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
    <div class="error"><?php echo $errors['email'] ?? ''; ?></div>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password">
    <div class="error"><?php echo $errors['password'] ?? ''; ?></div>

    <button type="submit">Kirim</button>
</form>

</body>
</html>
