<?php 
$errors = array(); 

if (isset($_POST['surname'])) { 
    require 'validate.inc';  
    validateName($errors, $_POST, 'surname');  

    if ($errors) { 
        echo '<h2 style="color:red;">Invalid, correct the following errors:</h2>';  
        foreach ($errors as $field => $error) {
            echo "<p>$field: $error</p>";
        }
        include 'form.inc'; 
    } 
    else { 
        echo '<h2 style="color:green;">Form submitted successfully with no errors!</h2>';
        echo '<p>Nama Anda: ' . htmlspecialchars($_POST['surname']) . '</p>';
    } 
} 
else {
    include 'form.inc'; 
}
?>
