<?php
$errors = [];
$nama = $nim = $email = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama']);
    if (empty($nama)) {
        $errors['nama'] = "Nama wajib diisi.";
    }
    $nim = trim($_POST['nim']);
    if (empty($nim)) {
        $errors['nim'] = "NIM wajib diisi.";
    }
    $email = trim($_POST['email']);
    if (empty($email)) {
        $errors['email'] = "Email wajib diisi.";
    }
    $password = trim($_POST['password']);
    if (empty($password)) {
        $errors['password'] = "Password wajib diisi.";
    }

    if (empty($errors)) {
        echo "<h3 '> Data valid dan berhasil dikirim!</h3>";
        echo "<p><strong>Nama:</strong> " . htmlspecialchars($nama) . "</p>";
        echo "<p><strong>NIM:</strong> " . htmlspecialchars($nim) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Input Mahasiswa</title>
   
   
</head>
<body>

<h2>Form Input Data Mahasiswa</h2>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label>Nama:</label>
    <input type="text" name="nama" value="<?php echo htmlspecialchars($nama); ?>">
    <div class="error"><?php echo $errors['nama'] ?? ''; ?></div>

    <label>NIM:</label>
    <input type="text" name="nim" value="<?php echo htmlspecialchars($nim); ?>">
    <div class="error"><?php echo $errors['nim'] ?? ''; ?></div>

    <label>Email:</label>
    <input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>">
    <div class="error"><?php echo $errors['email'] ?? ''; ?></div>

    <label>Password:</label>
    <input type="password" name="password">
    <div class="error"><?php echo $errors['password'] ?? ''; ?></div>

    <br>
    <button type="submit">Kirim</button>
</form>

</body>
</html>
