<?php
$errors = array();

if (isset($_POST['surname'])) {
    require 'validate.inc';
    validateName($errors, $_POST, 'surname');
    validateEmail($errors, $_POST, 'email');

    if ($errors) {
        echo '<h2 style="color:red;">Invalid, correct the following errors:</h2>';
        foreach ($errors as $field => $error) {
            echo "<p>$field: $error</p>";
        }
        include 'form.inc';
    } else {
        echo '<h2 style="color:green;">Form submitted successfully!</h2>';
        echo '<p>Nama: ' . htmlspecialchars($_POST['surname']) . '</p>';
        echo '<p>Email: ' . htmlspecialchars($_POST['email']) . '</p>';
    }
} else {
    include 'form.inc';
}
?>
